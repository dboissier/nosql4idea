# NoSql Plugin for IntelliJ IDEA version 0.1.0-SNAPSHOT

## Description
This plugin is a fork from [mongo4idea](https://github.com/dboissier/mongo4idea) and intends to integrate Redis and Couchbase databases.

## Plugin Compatibility
This plugin is built with JDK 1.6 and idea 14.1 version

## Current status
**Caution**: the current source code is still incomplete and should not be used

## Roadmap

### 0.1.0

* integrate Redis : view results with 'Group by prefix' feature like **properties editor**
* integrate Couchbase : view results like mongo

### 0.2.0

* delete, update and add features for Redis and Couchbase
